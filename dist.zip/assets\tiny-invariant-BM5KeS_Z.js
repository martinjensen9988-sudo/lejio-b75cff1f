function r(r,n){throw new Error("Invariant failed")}export{r as i};
